"""
Kayak Studio – Python backend
Flask server matching the real Kayak/SentientSands mod structure:
  Kayak/KayakDB/Campaigns/{campaign}/categories/{cat}/{entity}/entity.txt
  Kayak/KayakDB/Campaigns/{campaign}/mandatory/  (gameplay prompts)
  Kayak/KayakDB/Template/categories/ and Template/mandatory/
  server/config/models.json  &  server/config/providers.json
  config_master.txt  (INI, [SentientSands] section)
"""

import os
import sys
import json
import shutil
import re
import configparser
from pathlib import Path
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory
from parser import (
    parse_entity_file, document_to_dict, dict_to_document,
    scan_vocabulary
)

app = Flask(__name__, static_folder="static", static_url_path="/static")

# ── State ──
STATE = {
    "mod_root": "",
    "kayak_db": "",
    "campaigns_root": "",
    "template_root": "",
    "models": {},
    "providers": {},
    "active_model": "",
    "active_campaign": "",
    "vocabulary": {},
}

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
DEFAULT_MOD_ROOT = os.path.dirname(APP_ROOT)


# ── Mod resolution (mirrors fan explorer logic) ──

def resolve_mod_root(path: str) -> str:
    full = os.path.normpath(path)
    if os.path.isdir(os.path.join(full, "Kayak", "KayakDB")):
        return full
    ss = os.path.join(full, "SentientSands")
    if os.path.isdir(os.path.join(ss, "Kayak", "KayakDB")):
        return ss
    if os.path.isdir(full):
        for item in os.listdir(full):
            child = os.path.join(full, item)
            if os.path.isdir(os.path.join(child, "Kayak", "KayakDB")):
                return child
    return full


def validate_mod_root(path: str) -> dict:
    resolved = resolve_mod_root(path)
    required = [
        os.path.join("Kayak", "KayakDB"),
        os.path.join("server", "config", "models.json"),
        os.path.join("server", "config", "providers.json"),
    ]
    missing = [r for r in required if not os.path.exists(os.path.join(resolved, r))]
    return {"valid": len(missing) == 0, "resolved": resolved, "missing": missing}


def read_ini_value(filepath: str, section: str, key: str) -> str:
    if not os.path.isfile(filepath):
        return ""
    config = configparser.ConfigParser()
    config.read(filepath, encoding="utf-8")
    try:
        return config.get(section, key, fallback="")
    except (configparser.NoSectionError, configparser.NoOptionError):
        return ""


def load_json_file(filepath: str) -> dict:
    if not os.path.isfile(filepath):
        return {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def load_mod_context(mod_root: str):
    STATE["mod_root"] = mod_root
    STATE["kayak_db"] = os.path.join(mod_root, "Kayak", "KayakDB")
    STATE["campaigns_root"] = os.path.join(STATE["kayak_db"], "Campaigns")
    STATE["template_root"] = os.path.join(STATE["kayak_db"], "Template")

    STATE["models"] = load_json_file(os.path.join(mod_root, "server", "config", "models.json"))
    STATE["providers"] = load_json_file(os.path.join(mod_root, "server", "config", "providers.json"))

    config_master = os.path.join(mod_root, "config_master.txt")
    legacy_ini = os.path.join(mod_root, "SentientSands_Config.ini")

    STATE["active_model"] = (
        read_ini_value(config_master, "SentientSands", "CurrentModel") or
        read_ini_value(legacy_ini, "Settings", "CurrentModel") or ""
    )
    STATE["active_campaign"] = (
        read_ini_value(config_master, "SentientSands", "ActiveCampaign") or
        read_ini_value(legacy_ini, "Settings", "ActiveCampaign") or ""
    )


def get_campaigns() -> list:
    cr = STATE.get("campaigns_root", "")
    if not cr or not os.path.isdir(cr):
        return []
    return sorted([d for d in os.listdir(cr) if os.path.isdir(os.path.join(cr, d))])


def get_mode_root(campaign: str, mode: str) -> str:
    if campaign == "[Template]":
        base = STATE["template_root"]
    else:
        base = os.path.join(STATE["campaigns_root"], campaign)
    return os.path.join(base, "mandatory" if mode == "mandatory" else "categories")


def get_campaign_root(campaign: str) -> str:
    if campaign == "[Template]":
        return STATE["template_root"]
    return os.path.join(STATE["campaigns_root"], campaign)


def list_entity_tree(categories_root: str) -> list:
    """categories/{category_name}/{entity_name}/entity.txt"""
    result = []
    if not os.path.isdir(categories_root):
        return result
    for cat_name in sorted(os.listdir(categories_root)):
        cat_path = os.path.join(categories_root, cat_name)
        if not os.path.isdir(cat_path):
            continue
        entities = []
        for ent_name in sorted(os.listdir(cat_path)):
            ent_path = os.path.join(cat_path, ent_name)
            entity_file = os.path.join(ent_path, "entity.txt")
            if os.path.isdir(ent_path) and os.path.isfile(entity_file):
                entities.append({
                    "name": ent_name,
                    "path": os.path.relpath(entity_file, STATE["mod_root"]),
                })
        if entities or os.path.isdir(cat_path):
            result.append({"category": cat_name, "entities": entities, "count": len(entities)})
    return result


def list_mandatory_tree(mandatory_root: str) -> list:
    result = []
    if not os.path.isdir(mandatory_root):
        return result
    for root_dir, dirs, files in os.walk(mandatory_root):
        dirs.sort()
        for f in sorted(files):
            if f.endswith(".txt"):
                fp = os.path.join(root_dir, f)
                rel = os.path.relpath(fp, STATE["mod_root"])
                display = os.path.relpath(fp, mandatory_root)
                result.append({"name": display, "path": rel})
    return result


def is_editable_text_file(filename: str) -> bool:
    _, ext = os.path.splitext(filename.lower())
    return ext in {".txt", ".md", ".json", ".log", ".cfg", ".ini", ".yaml", ".yml", ".xml", ".csv"}


def list_recursive_tree(root: str) -> list:
    def build_nodes(current_dir: str) -> list:
        nodes = []

        for name in sorted(os.listdir(current_dir), key=str.lower):
            full_path = os.path.join(current_dir, name)
            if os.path.isdir(full_path):
                children = build_nodes(full_path)
                nodes.append({
                    "type": "dir",
                    "name": name,
                    "children": children,
                })
                continue

            if os.path.isfile(full_path) and is_editable_text_file(name):
                nodes.append({
                    "type": "file",
                    "name": name,
                    "path": os.path.relpath(full_path, STATE["mod_root"]),
                })

        return nodes

    if not os.path.isdir(root):
        return []
    return build_nodes(root)


# ── Model/provider resolution ──

def get_model_descriptor(model_key: str) -> dict:
    if not model_key or model_key not in STATE["models"]:
        return None
    model = STATE["models"][model_key]
    provider_key = model.get("provider", "")
    provider = STATE["providers"].get(provider_key)
    return {
        "model_key": model_key,
        "provider_key": provider_key,
        "model_name": model.get("model", model_key),
        "provider": provider,
    }


def get_providers_list() -> list:
    return sorted(STATE["providers"].keys())


def get_models_for_provider(provider_key: str) -> list:
    if not provider_key:
        return sorted(STATE["models"].keys())
    return sorted([k for k, v in STATE["models"].items() if v.get("provider") == provider_key])


# ── Routes ──

@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/api/open-mod", methods=["POST"])
def open_mod():
    data = request.json or {}
    path = data.get("path", "").strip() or DEFAULT_MOD_ROOT

    validation = validate_mod_root(path)
    if not validation["valid"]:
        return jsonify({
            "error": "Missing required paths: " + ", ".join(validation["missing"]),
            "resolved": validation["resolved"],
        }), 400

    load_mod_context(validation["resolved"])

    campaigns = get_campaigns()
    if not STATE["active_campaign"] and campaigns:
        STATE["active_campaign"] = campaigns[0]

    # Scan vocabulary
    try:
        cats_root = get_mode_root(STATE["active_campaign"], "categories") if STATE["active_campaign"] else ""
        template_cats = os.path.join(STATE["template_root"], "categories")
        for scan_path in [cats_root, template_cats]:
            if os.path.isdir(scan_path):
                STATE["vocabulary"] = scan_vocabulary(scan_path)
                break
    except Exception:
        STATE["vocabulary"] = {}

    return jsonify({
        "mod_root": STATE["mod_root"],
        "campaigns": campaigns,
        "active_campaign": STATE["active_campaign"],
        "active_model": STATE["active_model"],
        "providers": get_providers_list(),
        "models": sorted(STATE["models"].keys()),
    })


@app.route("/api/tree", methods=["GET"])
def get_tree():
    campaign = request.args.get("campaign", STATE.get("active_campaign", ""))
    mode = request.args.get("mode", "all")
    if mode == "mandatory":
        root = get_mode_root(campaign, "mandatory")
    elif mode == "categories":
        root = get_mode_root(campaign, "categories")
    else:
        root = get_campaign_root(campaign)

    return jsonify({"mode": mode, "tree": list_recursive_tree(root)})


@app.route("/api/file", methods=["GET"])
def get_file():
    rel_path = request.args.get("path", "")
    mod_root = STATE.get("mod_root", "")
    if not mod_root:
        return jsonify({"error": "No mod folder opened"}), 400

    target = os.path.normpath(os.path.join(mod_root, rel_path))
    if not target.startswith(os.path.normpath(mod_root)):
        return jsonify({"error": "Path outside mod root"}), 403
    if not os.path.isfile(target):
        return jsonify({"error": "File not found"}), 404

    try:
        doc = parse_entity_file(target)
        result = document_to_dict(doc)
    except Exception as e:
        result = {"blocks": [], "is_legacy": True, "parse_error": str(e)}

    with open(target, "r", encoding="utf-8", errors="replace") as f:
        result["raw_text"] = f.read()
    result["rel_path"] = rel_path

    raw_bytes = open(target, "rb").read(4096)
    result["has_bom"] = raw_bytes[:3] == b'\xef\xbb\xbf'
    result["newline"] = "crlf" if b"\r\n" in raw_bytes else "lf"

    return jsonify(result)


@app.route("/api/file", methods=["PUT"])
def save_file():
    data = request.json
    rel_path = data.get("rel_path", "")
    mod_root = STATE.get("mod_root", "")
    if not mod_root:
        return jsonify({"error": "No mod folder opened"}), 400

    target = os.path.normpath(os.path.join(mod_root, rel_path))
    if not target.startswith(os.path.normpath(mod_root)):
        return jsonify({"error": "Path outside mod root"}), 403

    # Backup
    if os.path.exists(target):
        backup_dir = os.path.join(mod_root, ".kayak-studio-backups")
        os.makedirs(backup_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = rel_path.replace(os.sep, "_").replace("/", "_")
        shutil.copy2(target, os.path.join(backup_dir, f"{safe_name}.{ts}.bak"))

    if data.get("save_mode") == "raw":
        content = data.get("raw_text", "")
    elif "blocks" in data:
        doc = dict_to_document(data)
        content = doc.to_text()
    else:
        content = data.get("raw_text", "")

    if data.get("newline") == "crlf":
        content = content.replace("\r\n", "\n").replace("\n", "\r\n")

    bom = b'\xef\xbb\xbf' if data.get("has_bom") else b''
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(bom + content.encode("utf-8"))

    return jsonify({"ok": True, "path": rel_path})


@app.route("/api/file/new", methods=["POST"])
def new_file():
    data = request.json
    campaign = data.get("campaign", STATE.get("active_campaign", ""))
    category = data.get("category", "base_npcs")
    entity_name = data.get("entity_name", "").strip()
    display_name = data.get("display_name", entity_name)

    if not entity_name:
        return jsonify({"error": "Entity name required"}), 400

    slug = re.sub(r'[^\w\-]+', '_', entity_name).strip('_') or 'new_entry'
    cats_root = get_mode_root(campaign, "categories")
    entity_dir = os.path.join(cats_root, category, slug)
    entity_file = os.path.join(entity_dir, "entity.txt")

    if os.path.exists(entity_file):
        return jsonify({"error": "Entity already exists"}), 409

    content = f"Category = {category}\nName = {slug}\nId = {slug}\n\n"
    content += f"display_name = {display_name}\n"
    if category in ("base_npcs", "campaign_npcs"):
        content += "race = Greenlander\nsex = male\nfaction = \nrole = \nweight = 5\n"
        content += "$knows_about = \n$personality = \n"
    else:
        content += "title = \n$summary = \n"

    os.makedirs(entity_dir, exist_ok=True)
    with open(entity_file, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)

    return jsonify({"ok": True, "path": os.path.relpath(entity_file, STATE["mod_root"])})


@app.route("/api/vocabulary", methods=["GET"])
def get_vocabulary():
    return jsonify(STATE.get("vocabulary", {}))


@app.route("/api/vocabulary/refresh", methods=["POST"])
def refresh_vocabulary():
    campaign = STATE.get("active_campaign", "")
    if campaign:
        cats_root = get_mode_root(campaign, "categories")
        if os.path.isdir(cats_root):
            STATE["vocabulary"] = scan_vocabulary(cats_root)
    return jsonify(STATE.get("vocabulary", {}))


@app.route("/api/ai/providers", methods=["GET"])
def ai_providers():
    return jsonify({
        "providers": get_providers_list(),
        "models": sorted(STATE["models"].keys()),
        "active_model": STATE.get("active_model", ""),
    })


@app.route("/api/ai/models", methods=["GET"])
def ai_models():
    provider = request.args.get("provider", "")
    return jsonify({"models": get_models_for_provider(provider)})


@app.route("/api/ai/draft", methods=["POST"])
def ai_draft():
    """Generate AI draft using mod's own model/provider config.
    All providers use OpenAI-compatible /chat/completions (like the fan tool)."""
    data = request.json
    model_key = data.get("model_key", STATE.get("active_model", ""))
    instructions = data.get("instructions", "")
    current_text = data.get("current_text", "")
    reference_text = data.get("reference_text", "")
    entity_type = data.get("entity_type", "entity")

    descriptor = get_model_descriptor(model_key)
    if not descriptor:
        return jsonify({"error": f"Model '{model_key}' not found in models.json"}), 400
    if not descriptor["provider"]:
        return jsonify({"error": f"Provider '{descriptor['provider_key']}' not found in providers.json"}), 400

    provider = descriptor["provider"]
    api_key = provider.get("api_key", "")
    base_url = provider.get("base_url", "")
    if not base_url:
        return jsonify({"error": f"Provider '{descriptor['provider_key']}' has no base_url"}), 400

    if api_key and re.match(r'^(YOUR_|REPLACE_|CHANGEME|PUT_)', api_key):
        if descriptor["provider_key"] not in ("ollama", "player2"):
            return jsonify({"error": f"Provider '{descriptor['provider_key']}' has a placeholder API key"}), 400

    if entity_type == "mandatory":
        prompt_text = f"""Generate a Sentient Sands mandatory prompt file.

Rules:
- Keep the output in plain text only.
- Preserve the tone and structure conventions used by sibling mandatory prompt files.
- Do not add markdown fences or commentary.

Current file:
<<<CURRENT
{current_text}
CURRENT

Reference example:
<<<REFERENCE
{reference_text}
REFERENCE

User instructions:
{instructions}"""
    else:
        prompt_text = f"""Generate a KayakDB entity.txt entry for Sentient Sands.

Rules:
- Return only the final entity.txt content.
- Keep the first three header lines exactly in this order: Category, Name, Id.
- Preserve field ordering and style from the supplied schema/reference.
- Use $ prefixes only where the schema/reference implies prose fields.
- Do not add markdown fences or commentary.

Current schema/content:
<<<CURRENT
{current_text}
CURRENT

Reference example:
<<<REFERENCE
{reference_text}
REFERENCE

User instructions:
{instructions}"""

    import urllib.request
    import ssl

    uri = base_url.rstrip("/")
    if not uri.endswith("/chat/completions"):
        uri += "/chat/completions"

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = {
        "model": descriptor["model_name"],
        "temperature": 0.7,
        "messages": [
            {"role": "system", "content": "You generate Sentient Sands / Kayak prompt files. Return only the final file content."},
            {"role": "user", "content": prompt_text},
        ],
    }

    try:
        req = urllib.request.Request(uri, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=90, context=ctx) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        choices = result.get("choices", [])
        if not choices:
            return jsonify({"error": "No completion choices returned"}), 500

        content = choices[0].get("message", {}).get("content", "").strip()
        if not content:
            return jsonify({"error": "Provider returned empty draft"}), 500

        return jsonify({"draft": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    print(f"\n  Kayak Studio running at http://localhost:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=False)
