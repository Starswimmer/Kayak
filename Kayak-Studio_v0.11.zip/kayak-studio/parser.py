"""
AIDSL Document Model and Parser

Line-based state-machine parser for Kayak entity files.
Supports both legacy flat format and new AIDSL structured format.
Produces a normalized document model that the editor can work with.
"""

import re
import os
import json
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


class BlockType(Enum):
    HEADER = "header"           # H1: CAMPAIGN_NPCS
    SECTION = "section"         # Identity:, Body:, Faction:
    KV = "kv"                   # key = value
    AIDSL_FIELD = "aidsl_field" # ((key = value)) / ((key: 'value'))
    SEMANTIC = "semantic"       # (( ... ))
    WEIGHTED_SEMANTIC = "weighted_semantic"  # W100% - (( ... ))
    PROSE = "prose"             # $field: text...
    CATEGORY_LINE = "category"  # Category = ...
    NAME_LINE = "name"          # Name = ...
    ID_LINE = "id"              # Id = ...
    BLANK = "blank"
    RAW = "raw"                 # anything unparseable


@dataclass
class SemanticTrait:
    """Single trait inside a semantic group, e.g. @fanatic"""
    value: str            # the trait text (without @)
    priority: bool = False  # wrapped in >> <<

    def to_aidsl(self) -> str:
        v = f"@{self.value}" if not self.value.startswith("@") else self.value
        if "=" in self.value and not self.value.startswith("@"):
            v = f"@{self.value}"
        return f">>{v}<<" if self.priority else v


@dataclass
class SemanticGroup:
    """A group of traits combined with &, e.g. '@fanatic & @paranoid'"""
    traits: list  # list of SemanticTrait

    def to_aidsl(self) -> str:
        return " & ".join(t.to_aidsl() for t in self.traits)


@dataclass
class SemanticBlock:
    """Full semantic block: ((Category: group1 or group2))"""
    category: str
    groups: list  # list of SemanticGroup (separated by 'or')
    weight: Optional[int] = None  # W% prefix for parser, None for character files

    def to_aidsl(self) -> str:
        inner = " OR ".join(g.to_aidsl() for g in self.groups)
        core = f"(({self.category}: {inner}))"
        if self.weight is not None:
            return f"W{self.weight}% - {core}"
        return core

    def to_ai_text(self) -> str:
        """AI-facing version: no W% prefix"""
        inner = " OR ".join(g.to_aidsl() for g in self.groups)
        return f"(({self.category}: {inner}))"


@dataclass
class DocumentBlock:
    """A block in the document model"""
    block_type: BlockType
    raw_text: str  # original text for round-trip safety
    key: str = ""
    value: str = ""
    operator: str = ""
    quoted: bool = False
    quote_char: str = "'"
    semantic: Optional[SemanticBlock] = None
    section_name: str = ""
    children: list = field(default_factory=list)  # for sections


@dataclass
class EntityDocument:
    """Full parsed entity document"""
    category: str = ""
    name: str = ""
    entity_id: str = ""
    blocks: list = field(default_factory=list)
    file_path: str = ""
    is_legacy: bool = True  # True if old flat format detected

    def to_text(self) -> str:
        lines = []
        for b in self.blocks:
            if b.block_type == BlockType.RAW:
                lines.append(b.raw_text)
            elif b.block_type == BlockType.BLANK:
                lines.append("")
            elif b.block_type == BlockType.HEADER:
                lines.append(f"H1: {b.value}")
            elif b.block_type == BlockType.SECTION:
                lines.append(f"{b.section_name}:")
            elif b.block_type == BlockType.CATEGORY_LINE:
                lines.append(f"Category = {b.value}")
            elif b.block_type == BlockType.NAME_LINE:
                lines.append(f"Name = {b.value}")
            elif b.block_type == BlockType.ID_LINE:
                lines.append(f"Id = {b.value}")
            elif b.block_type == BlockType.KV:
                lines.append(f"{b.key} = {b.value}")
            elif b.block_type == BlockType.AIDSL_FIELD:
                if b.operator == "=":
                    lines.append(f"(({b.key} = {format_aidsl_value(b.value, b.quoted, b.quote_char)}))")
                else:
                    lines.append(f"(({b.key}: {format_aidsl_value(b.value, b.quoted, b.quote_char)}))")
            elif b.block_type == BlockType.PROSE:
                lines.append(f"${b.key}: {b.value}")
            elif b.block_type in (BlockType.SEMANTIC, BlockType.WEIGHTED_SEMANTIC):
                if b.semantic:
                    lines.append(b.semantic.to_aidsl())
                else:
                    lines.append(b.raw_text)
            else:
                lines.append(b.raw_text)
        return "\n".join(lines)


# ── Regex patterns ──

RE_HEADER = re.compile(r'^H1:\s*(.+)$')
RE_SECTION = re.compile(r'^([A-Za-z_][A-Za-z0-9_ ]*):$')
RE_WEIGHTED_SEMANTIC = re.compile(r'^W(\d+)%\s*-\s*\(\((.+)\)\)\s*$')
RE_SEMANTIC = re.compile(r'^\(\((.+)\)\)\s*$')
RE_AIDSL_FIELD = re.compile(r'^([A-Za-z_][A-Za-z0-9_ ]*)\s*([:=])\s*(.+)$', re.DOTALL)
RE_PROSE = re.compile(r'^\$([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*(.*)$', re.DOTALL)
RE_CATEGORY = re.compile(r'^Category\s*=\s*(.+)$')
RE_NAME = re.compile(r'^Name\s*=\s*(.+)$')
RE_ID = re.compile(r'^Id\s*=\s*(.+)$')
RE_KV = re.compile(r'^(\$?[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$')
RE_PROSE_DOLLAR_KV = re.compile(r'^\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$')


def format_aidsl_value(value: str, quoted: bool = False, quote_char: str = "'") -> str:
    if not quoted:
        return value
    escaped = (value or "").replace("\\", "\\\\").replace(quote_char, "\\" + quote_char)
    return f"{quote_char}{escaped}{quote_char}"


def unwrap_aidsl_value(value: str) -> tuple[str, bool, str]:
    stripped = (value or "").strip()
    if len(stripped) >= 2 and stripped[0] in ("'", '"') and stripped[-1] == stripped[0]:
        quote_char = stripped[0]
        inner = stripped[1:-1]
        out = []
        escape = False
        for ch in inner:
            if escape:
                if ch in (quote_char, "\\"):
                    out.append(ch)
                else:
                    out.append("\\")
                    out.append(ch)
                escape = False
            elif ch == "\\":
                escape = True
            else:
                out.append(ch)
        if escape:
            out.append("\\")
        return "".join(out), True, quote_char
    return stripped, False, "'"


def parse_semantic_content(content: str) -> list:
    """Parse semantic content after the category label."""
    if not content:
        return [SemanticGroup([SemanticTrait("")])]

    # Split by ' or ' for alternative groups
    or_parts = re.split(r'\s+OR\s+', content, flags=re.IGNORECASE)
    groups = []
    for part in or_parts:
        # Split by ' & ' for combined traits
        and_parts = re.split(r'\s*&\s*', part.strip())
        traits = []
        for trait_str in and_parts:
            trait_str = trait_str.strip().strip("'\"")
            priority = False
            # Check for >> <<
            pm = re.match(r'^>>(.+)<<$', trait_str)
            if pm:
                priority = True
                trait_str = pm.group(1).strip()
            # Check for = (value definition)
            traits.append(SemanticTrait(value=trait_str.lstrip("@"), priority=priority))
        groups.append(SemanticGroup(traits))
    return groups


def parse_semantic_inner(inner: str) -> tuple:
    """Parse inside of (( )) → (category, list_of_SemanticGroup)"""
    colon_idx = inner.find(":")
    if colon_idx == -1:
        return inner.strip(), [SemanticGroup([SemanticTrait(inner.strip())])]

    category = inner[:colon_idx].strip()
    content = inner[colon_idx + 1:].strip()
    return category, parse_semantic_content(content)


def looks_like_semantic_payload(value: str) -> bool:
    if not value:
        return False
    stripped = value.strip()
    if not stripped:
        return False
    if stripped[0] in ("'", '"'):
        return False
    return any(token in stripped for token in ("@", "&", ">>")) or re.search(r'\s+OR\s+', stripped, re.IGNORECASE) is not None


def parse_aidsl_container(inner: str, raw_line: str) -> DocumentBlock:
    m = RE_AIDSL_FIELD.match(inner.strip())
    if not m:
        cat, groups = parse_semantic_inner(inner)
        return DocumentBlock(BlockType.SEMANTIC, raw_line, semantic=SemanticBlock(category=cat, groups=groups))

    key = m.group(1).strip()
    operator = m.group(2)
    raw_value = m.group(3).strip()
    if operator == ":" and looks_like_semantic_payload(raw_value):
        groups = parse_semantic_content(raw_value)
        return DocumentBlock(BlockType.SEMANTIC, raw_line, semantic=SemanticBlock(category=key, groups=groups))

    value, quoted, quote_char = unwrap_aidsl_value(raw_value)
    return DocumentBlock(
        BlockType.AIDSL_FIELD,
        raw_line,
        key=key,
        value=value,
        operator=operator,
        quoted=quoted,
        quote_char=quote_char,
    )


def parse_line(line: str) -> DocumentBlock:
    """Parse a single line into a DocumentBlock."""
    stripped = line.strip()

    if not stripped:
        return DocumentBlock(BlockType.BLANK, line)

    # Header
    m = RE_HEADER.match(stripped)
    if m:
        return DocumentBlock(BlockType.HEADER, line, value=m.group(1).strip())

    # Category
    m = RE_CATEGORY.match(stripped)
    if m:
        return DocumentBlock(BlockType.CATEGORY_LINE, line, value=m.group(1).strip())

    # Name
    m = RE_NAME.match(stripped)
    if m:
        return DocumentBlock(BlockType.NAME_LINE, line, value=m.group(1).strip())

    # Id
    m = RE_ID.match(stripped)
    if m:
        return DocumentBlock(BlockType.ID_LINE, line, value=m.group(1).strip())

    # Weighted semantic
    m = RE_WEIGHTED_SEMANTIC.match(stripped)
    if m:
        weight = int(m.group(1))
        cat, groups = parse_semantic_inner(m.group(2))
        sb = SemanticBlock(category=cat, groups=groups, weight=weight)
        return DocumentBlock(BlockType.WEIGHTED_SEMANTIC, line, semantic=sb)

    # Semantic
    m = RE_SEMANTIC.match(stripped)
    if m:
        return parse_aidsl_container(m.group(1), line)

    # Prose with $key: value
    m = RE_PROSE.match(stripped)
    if m:
        return DocumentBlock(BlockType.PROSE, line, key=m.group(1), value=m.group(2).strip())

    # Prose with $key = value (legacy)
    m = RE_PROSE_DOLLAR_KV.match(stripped)
    if m:
        return DocumentBlock(BlockType.PROSE, line, key=m.group(1), value=m.group(2).strip())

    # Section header (word followed by colon alone on line)
    m = RE_SECTION.match(stripped)
    if m and len(m.group(1)) < 40:
        return DocumentBlock(BlockType.SECTION, line, section_name=m.group(1))

    # Generic key = value
    m = RE_KV.match(stripped)
    if m:
        key = m.group(1)
        val = m.group(2).strip()
        return DocumentBlock(BlockType.KV, line, key=key, value=val)

    # Fallback: raw
    return DocumentBlock(BlockType.RAW, line)


def parse_entity_file(filepath: str) -> EntityDocument:
    """Parse an entity file into an EntityDocument."""
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    doc = EntityDocument(file_path=filepath)
    has_aidsl = False

    for line in content.split("\n"):
        block = parse_line(line)
        doc.blocks.append(block)

        if block.block_type == BlockType.CATEGORY_LINE:
            doc.category = block.value
        elif block.block_type == BlockType.NAME_LINE:
            doc.name = block.value
        elif block.block_type == BlockType.ID_LINE:
            doc.entity_id = block.value
        elif block.block_type in (BlockType.HEADER, BlockType.AIDSL_FIELD, BlockType.SEMANTIC,
                                   BlockType.WEIGHTED_SEMANTIC, BlockType.SECTION):
            has_aidsl = True

    doc.is_legacy = not has_aidsl
    return doc


def document_to_dict(doc: EntityDocument) -> dict:
    """Convert EntityDocument to JSON-serializable dict for the frontend."""
    blocks = []
    for b in doc.blocks:
        bd = {
            "type": b.block_type.value,
            "raw": b.raw_text,
            "key": b.key,
            "value": b.value,
            "operator": b.operator,
            "quoted": b.quoted,
            "quote_char": b.quote_char,
            "section_name": b.section_name,
        }
        if b.semantic:
            s = b.semantic
            bd["semantic"] = {
                "category": s.category,
                "weight": s.weight,
                "groups": [
                    {
                        "traits": [
                            {"value": t.value, "priority": t.priority}
                            for t in g.traits
                        ]
                    }
                    for g in s.groups
                ]
            }
        blocks.append(bd)

    return {
        "category": doc.category,
        "name": doc.name,
        "entity_id": doc.entity_id,
        "file_path": doc.file_path,
        "is_legacy": doc.is_legacy,
        "blocks": blocks,
    }


def dict_to_document(data: dict) -> EntityDocument:
    """Rebuild an EntityDocument from JSON dict (from frontend save)."""
    doc = EntityDocument(
        category=data.get("category", ""),
        name=data.get("name", ""),
        entity_id=data.get("entity_id", ""),
        file_path=data.get("file_path", ""),
        is_legacy=data.get("is_legacy", True),
    )
    for bd in data.get("blocks", []):
        bt = BlockType(bd["type"])
        block = DocumentBlock(
            block_type=bt,
            raw_text=bd.get("raw", ""),
            key=bd.get("key", ""),
            value=bd.get("value", ""),
            operator=bd.get("operator", ""),
            quoted=bd.get("quoted", False),
            quote_char=bd.get("quote_char", "'"),
            section_name=bd.get("section_name", ""),
        )
        if bd.get("semantic"):
            s = bd["semantic"]
            groups = []
            for g in s.get("groups", []):
                traits = [SemanticTrait(t["value"], t.get("priority", False))
                          for t in g.get("traits", [])]
                groups.append(SemanticGroup(traits))
            block.semantic = SemanticBlock(
                category=s["category"],
                groups=groups,
                weight=s.get("weight"),
            )
        doc.blocks.append(block)
    return doc


# ── Vocabulary discovery ──

def scan_vocabulary(root_dir: str) -> dict:
    """Scan all entity files and extract vocabulary:
    categories, keys, values, prose fields, semantic categories, traits."""
    vocab = {
        "categories": set(),
        "keys": set(),
        "values": {},        # key -> set of values seen
        "prose_fields": set(),
        "semantic_categories": set(),
        "traits": set(),
        "factions": set(),
        "races": set(),
        "locations": set(),
    }

    for dirpath, _, filenames in os.walk(root_dir):
        for fn in filenames:
            if not fn.endswith(".txt"):
                continue
            fp = os.path.join(dirpath, fn)
            try:
                doc = parse_entity_file(fp)
            except Exception:
                continue

            if doc.category:
                vocab["categories"].add(doc.category)

            for b in doc.blocks:
                if b.block_type in (BlockType.KV, BlockType.AIDSL_FIELD) and b.operator in ("", "="):
                    vocab["keys"].add(b.key)
                    if b.key not in vocab["values"]:
                        vocab["values"][b.key] = set()
                    if b.value:
                        for v in b.value.split(","):
                            v = v.strip()
                            if v:
                                vocab["values"][b.key].add(v)
                    # Track special keys
                    if b.key == "faction":
                        vocab["factions"].add(b.value)
                    elif b.key == "race":
                        vocab["races"].add(b.value)
                    elif b.key == "location":
                        vocab["locations"].add(b.value)

                elif b.block_type == BlockType.PROSE or (b.block_type == BlockType.AIDSL_FIELD and b.operator == ":"):
                    vocab["prose_fields"].add(b.key)

                elif b.block_type in (BlockType.SEMANTIC, BlockType.WEIGHTED_SEMANTIC):
                    if b.semantic:
                        vocab["semantic_categories"].add(b.semantic.category)
                        for g in b.semantic.groups:
                            for t in g.traits:
                                vocab["traits"].add(t.value)

    # Convert sets to sorted lists for JSON
    result = {}
    for k, v in vocab.items():
        if isinstance(v, set):
            result[k] = sorted(v)
        elif isinstance(v, dict):
            result[k] = {kk: sorted(vv) for kk, vv in v.items()}
        else:
            result[k] = v
    return result
