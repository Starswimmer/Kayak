"""
Kayak ↔ Sentient Sands bridge.

This bridge handles all integration between SentientSands and Kayak:
  • Campaign switching on save load
  • Writing NPC profiles to KayakDB (entity.txt) — including Traits
  • Writing live stats (stats.txt, prompt-time read)
  • Persisting dialogue turns for the primary NPC (dialogue.txt)
  • Persisting overheard dialogue for NPC listeners (dialogue.txt with prefix)
  • Building chat / loremaster / biography prompts
  • Translating SentientSands payload format into clean Kayak calls

─── HOW TO USE IN kenshi_llm_server.py ──────────────────────────────────────

See the docstring sections inline for each hook location.
"""

import logging
import os
import re
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger("kayak.bridge.sentient_sands")


# ─── FACTION KNOWLEDGE TABLE ─────────────────────────────────────────────────
#
# Maps lowercase faction name → set of entity folder names this faction's
# members would plausibly know about.  Used to seed $knows_about on first
# profile write.  Both the NPC's Faction AND OriginFaction are merged so a
# Holy Nation defector who joined the Anti-Slavers still remembers Blister Hill.
#
# Rule of thumb:
#   • Own territory cities + faction names — always
#   • Direct enemies — always (you know what's trying to kill you)
#   • Neutral contacts encountered on trade / patrol routes — usually
#   • Far-away neutral factions / enemy sub-cities — only if widely known
#   • Isolated/feral factions (Fogmen, Cannibals core) — almost nothing

_FACTION_KNOWLEDGE: dict = {
    "holy nation": {
        "Blister_Hill", "Bad_Teeth", "Stack", "Rebirth", "Holy_Lands",
        "Holy_Farms", "Holy_Mines", "Holy_Military_Bases",
        "Narko_s_Trap", "Okran_s_Fist", "Okran_s_Shield",
        "Okran_s_Pride", "Okran_s_Valley", "Okran_s_Gulf", "Skinner_s_Roam",
        "Arm_of_Okran",
        "Holy_Nation", "Shek_Kingdom", "United_Cities",
        "Flotsam_Ninjas", "Tech_Hunters", "Worlds_End",
        "Holy_Phoenix",
        "Okran_and_Narko", "The_Okranite_Rebellion",
        "The_Thousand_Year_War", "The_Slave_Economy",
    },
    "holy nation outlaws": {
        "The_Hub", "Border_Zone", "Holy_Lands", "Bad_Teeth", "Blister_Hill",
        "Okran_s_Pride", "Okran_s_Valley",
        "Holy_Nation", "Holy_Nation_Outlaws", "Flotsam_Ninjas",
        "Shek_Kingdom", "United_Cities",
    },
    "united cities": {
        "Heft", "Heng", "Catun", "Black_Scratch", "Flats_Lagoon",
        "Stoat", "Bark", "Brink", "Sho_Battai", "Eyesocket",
        "Port_North", "Port_South", "Stone_Camp",
        "Drifters_Last", "Clownsteady", "Trader_s_Edge",
        "Great_Desert", "Bonefields", "South_Wetlands", "Stormgap_Coast",
        "The_Hook", "Skimsands", "Sinkuun",
        "Border_Zone", "The_Hub",
        "United_Cities", "Traders_Guild", "Slave_Traders", "Manhunters",
        "Anti_Slavers", "Holy_Nation", "Shek_Kingdom", "Tech_Hunters",
        "Emperor_Tengu", "Longen",
        "The_Slave_Economy", "The_Red_Rebellion",
    },
    "traders guild": {
        "Heft", "Heng", "Catun", "Black_Scratch", "Flats_Lagoon",
        "Trader_s_Edge", "Eyesocket", "Great_Desert",
        "Border_Zone", "The_Hub",
        "United_Cities", "Traders_Guild", "Slave_Traders", "Shinobi_Thieves",
        "Anti_Slavers", "Holy_Nation", "Shek_Kingdom", "Tech_Hunters",
        "Longen",
        "The_Slave_Economy",
    },
    "slave traders": {
        "Heft", "Heng", "Eyesocket", "Port_North", "Port_South",
        "Stone_Camp", "Great_Desert", "Stormgap_Coast",
        "United_Cities", "Traders_Guild", "Slave_Traders", "Manhunters",
        "Anti_Slavers",
        "The_Slave_Economy",
    },
    "manhunters": {
        "Heft", "Heng", "Catun", "Eyesocket", "Port_North",
        "Great_Desert", "Stormgap_Coast", "The_Hook",
        "United_Cities", "Traders_Guild", "Slave_Traders", "Manhunters",
    },
    "shek kingdom": {
        "Admag", "Squin", "The_Great_Fortress", "Last_Stand",
        "Stenn_Desert", "Border_Zone",
        "Shek_Kingdom", "Holy_Nation", "United_Cities",
        "Kral_s_Chosen", "Band_of_Bones", "Berserkers",
        "Esata_the_Stone_Golem",
        "The_Shek_Extinction_Crisis", "The_Thousand_Year_War",
    },
    "kral's chosen": {
        "Admag", "Squin", "Stenn_Desert", "Border_Zone", "The_Hook",
        "Shek_Kingdom", "Holy_Nation", "United_Cities",
        "Kral_s_Chosen", "Band_of_Bones", "Berserkers",
        "Flying_Bull",
        "The_Shek_Extinction_Crisis", "The_Thousand_Year_War",
    },
    "band of bones": {
        "Admag", "Stenn_Desert",
        "Shek_Kingdom", "Holy_Nation", "United_Cities",
        "Band_of_Bones", "Kral_s_Chosen", "Berserkers",
        "The_Shek_Extinction_Crisis", "The_Thousand_Year_War",
    },
    "berserkers": {
        "Admag", "Stenn_Desert", "Berserker_Country",
        "Shek_Kingdom", "Holy_Nation",
        "Berserkers", "Kral_s_Chosen",
    },
    "tech hunters": {
        "Blister_Hill", "Bad_Teeth", "Stack", "Admag", "Squin",
        "Heft", "Heng", "Catun", "Black_Scratch", "Flats_Lagoon", "Worlds_End",
        "Scraphouse", "Mourn", "The_Crags", "The_Outlands",
        "Shark", "Mongrel", "Spring", "Black_Desert_City",
        "Floodlands", "Obedience_Zone",
        "Great_Desert", "Holy_Lands", "Stenn_Desert", "Border_Zone",
        "Fog_Islands", "Ashlands_Region", "Deadlands", "Iron_Valleys",
        "Black_Desert", "Grey_Desert", "Greyshelf", "Stobe_s_Gamble",
        "Leviathan_Coast", "Northern_Coast", "Shun", "Venge", "Royal_Valley",
        "Holy_Nation", "United_Cities", "Shek_Kingdom", "Anti_Slavers",
        "Flotsam_Ninjas", "Western_Hive", "Tech_Hunters", "Traders_Guild",
        "Second_Empire_Exiles", "The_First_Empire", "The_Second_Empire",
        "The_Chaos_Age", "The_Hydraulic_Knights", "Obedience",
        "Burn", "Sadneil",
        "The_War_of_Behemoths", "Stobe_the_Behemoth",
        "The_Fleshless_Doctrine", "Okran_and_Narko", "The_Okranite_Rebellion",
        "The_Red_Rebellion", "The_Shek_Extinction_Crisis",
        "The_Thousand_Year_War", "The_Slave_Economy",
        "The_Hive_Queens", "The_First_Empire_Technology", "Kenshi_the_Moon",
    },
    "anti-slavers": {
        "Spring", "Stobe_s_Gamble", "Heft", "Heng", "Eyesocket",
        "Port_North", "Stone_Camp", "Great_Desert",
        "United_Cities", "Traders_Guild", "Slave_Traders", "Holy_Nation",
        "Shek_Kingdom", "Flotsam_Ninjas", "Anti_Slavers", "Tech_Hunters",
        "Tinfist", "Bo",
        "The_Slave_Economy", "The_Second_Empire", "The_First_Empire",
    },
    "flotsam ninjas": {
        "Flotsam_Village", "Hidden_Forest", "Blister_Hill", "Bad_Teeth",
        "Rebirth", "Holy_Lands", "Okran_s_Gulf", "Border_Zone", "The_Hub",
        "Cannibal_Plains", "Northern_Coast",
        "Holy_Nation", "Flotsam_Ninjas", "Anti_Slavers", "Cannibals",
        "United_Cities", "Shek_Kingdom",
        "Moll",
        "Okran_and_Narko", "The_Okranite_Rebellion", "The_Slave_Economy",
    },
    "western hive": {
        "Hive_Village", "Vain", "Dreg", "Sinkuun",
        "Heft", "Heng", "Great_Desert",
        "Northern_Coast", "Leviathan_Coast",
        "United_Cities", "Traders_Guild", "Western_Hive",
    },
    "dark hive": {
        "Border_Zone", "The_Hub", "Great_Desert",
        "United_Cities", "Traders_Guild", "Western_Hive", "Dark_Hive",
    },
    "shinobi thieves": {
        "Heft", "Heng", "Catun", "Shark", "Mongrel", "The_Hub", "Border_Zone",
        "The_Swamp",
        "United_Cities", "Shinobi_Thieves", "Traders_Guild",
    },
    "nomads": {
        "The_Hub", "Border_Zone", "Great_Desert", "Heft", "Heng",
        "Stenn_Desert", "Admag", "Blister_Hill", "Bad_Teeth",
        "Raptor_Island",
        "United_Cities", "Holy_Nation", "Shek_Kingdom", "Traders_Guild",
        "Nomads",
    },
    "reavers": {
        "Ark", "Great_Desert", "The_Hook", "Stormgap_Coast", "Brink",
        "South_Wetlands", "Shun",
        "United_Cities", "Slave_Traders", "Reavers",
        "Valamon",
    },
    "dust bandits": {
        "The_Hub", "Border_Zone",
        "Holy_Nation", "United_Cities", "Dust_Bandits",
    },
    "starving bandits": {
        "The_Hub", "Border_Zone",
    },
    "cannibals": {
        "Cannibal_Plains", "Darkfinger",
        "Cannibals",
    },
    "skin bandits": {
        "Skin_Bandits",
    },
    "fogmen": set(),
    "second empire exiles": {
        "Ashlands_Region", "Cat_Lons_Exile", "Greyshelf",
        "Black_Desert", "Black_Desert_City", "Grey_Desert",
        "Royal_Valley", "Venge",
        "Second_Empire_Exiles", "The_Second_Empire",
        "The_First_Empire", "The_Chaos_Age", "Obedience",
        "Cat_Lon", "General_Jang", "Rhinobot", "General_Hat_12",
        "The_War_of_Behemoths", "The_Hydraulic_Knights",
        "Stobe_the_Behemoth", "The_Okranite_Rebellion",
        "The_Slave_Economy", "The_First_Empire_Technology", "Kenshi_the_Moon",
    },
    "skeleton bandits": {
        "Black_Desert", "Black_Desert_City", "Iron_Valleys", "Deadlands",
    },
    "preacher cult": {
        "Stormgap_Coast", "Brink",
    },
    "spider clan": {
        "Spider_Plains", "Black_Desert",
    },
    "crab raiders": {
        "Crab_Town", "The_Hook",
    },
    "mongrel": {
        "Mongrel", "Fog_Islands",
    },
    # Default — generic wanderer / unknown faction
    "_default": {
        "The_Hub", "Border_Zone",
    },
}

def _build_initial_knowledge(faction: str, origin_faction: str = "") -> set:
    """
    Return the union of knowledge seeds for the NPC's current faction
    and their origin faction.  Falls back to _default for unknowns.
    """
    f1 = faction.lower().strip()
    f2 = origin_faction.lower().strip()
    seed = (
        _FACTION_KNOWLEDGE.get(f1)
        or _FACTION_KNOWLEDGE.get(f2)
        or _FACTION_KNOWLEDGE["_default"]
    ).copy()
    if f2 and f2 != f1:
        extra = _FACTION_KNOWLEDGE.get(f2, set())
        seed |= extra
    return seed


class SentientSandsBridge:
    """
    HTTP client that bridges Sentient Sands ↔ Kayak.
    Translates SS payload shapes into Kayak API calls.
    """

    def __init__(
        self,
        kayak_url: str = "http://127.0.0.1:5001",
        campaign:  Optional[str] = None,
        timeout:   float = 10.0,
    ):
        self.kayak_url = kayak_url.rstrip("/")
        self.campaign  = campaign
        self.timeout   = timeout
        if campaign:
            self.on_save_loaded(campaign)

    # ─── CAMPAIGN ────────────────────────────────────────────────────────

    def on_save_loaded(self, campaign_name: str, ss_campaign_dir: Optional[str] = None):
        """
        Call every time a SentientSands campaign is activated.
        Creates from Template if new, then loads + reindexes.
        If ss_campaign_dir is supplied, also syncs the player bio file.

        Hook location in kenshi_llm_server.py: inside switch_campaign(), after
        load_campaign_config() and update_world_index().

        Pass ss_campaign_dir = os.path.join(CAMPAIGNS_DIR, campaign_name)
        so the bridge can read character_bio.txt and player_faction_description.txt.
        """
        result = self._post("/campaign/switch", {"name": campaign_name})
        if "error" in result:
            log.error(f"[Kayak] Failed to switch to '{campaign_name}': {result['error']}")
            return
        self.campaign = campaign_name
        idx = result.get("index", {})
        log.info(
            f"[Kayak] Campaign {'created' if result.get('created') else 'loaded'}: "
            f"'{campaign_name}' — {idx.get('entities', '?')} entities"
        )
        if ss_campaign_dir:
            self.sync_player_bio(ss_campaign_dir, campaign_name)

    def sync_player_bio(self, ss_campaign_dir: str, campaign: Optional[str] = None):
        """
        Read SentientSands' character_bio.txt and player_faction_description.txt
        from the campaign folder and write them as the per-campaign mandatory file
        KayakDB/Campaigns/<name>/mandatory/Chat/5_player_bio.txt.

        This file is loaded by Kayak as the last mandatory block before world context,
        so the LLM always knows who the player character is for this campaign.

        Called automatically from on_save_loaded() when ss_campaign_dir is supplied.
        Can also be called standalone to refresh after the player edits their bio.
        """
        bio_path  = os.path.join(ss_campaign_dir, "character_bio.txt")
        fac_path  = os.path.join(ss_campaign_dir, "player_faction_description.txt")

        bio_text  = _read_text(bio_path)
        fac_text  = _read_text(fac_path)

        if not bio_text and not fac_text:
            log.debug(f"[Kayak] sync_player_bio: no bio files found in {ss_campaign_dir}")
            return

        parts = []
        if bio_text:
            parts.append(bio_text.strip())
        if fac_text and fac_text.strip():
            parts.append(fac_text.strip())

        content = "\n\n".join(parts)

        payload: Dict[str, Any] = {
            "filename":   "5_player_bio.txt",
            "content":    content,
            "scope":      "campaign",
            "prompt_type": "Chat",
        }
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign

        result = self._post("/write/mandatory", payload)
        if "error" in result:
            log.warning(f"[Kayak] sync_player_bio failed: {result['error']}")
        else:
            log.info(f"[Kayak] Player bio synced for campaign '{campaign or self.campaign}'")

    # ─── WRITE: NPC PROFILE ──────────────────────────────────────────────

    def write_npc_profile(
        self,
        char_data: Dict[str, Any],
        campaign:  Optional[str] = None,
    ):
        """
        Write or update an NPC profile as entity.txt in KayakDB.

        Takes SentientSands char_data dict (as in save_character_data).
        Captures: Name, Race, Sex, Faction, OriginFaction, Job, Traits
        (Loyalty/Religion/Outlook/Motivation), Personality, Backstory,
        SpeechQuirks, Relation, ID (persistent_id).

        Hook location: inside save_character_data(), after dack.save(data, cfg_path).
        Original .cfg files are preserved alongside — Kayak is the source of truth
        for prompt building. To revert: set KAYAK_ENABLED = False.
        """
        name = _clean_name(char_data.get("Name") or char_data.get("name") or "")
        if not name:
            return

        folder_name   = _to_folder_name(name)
        persistent_id = str(char_data.get("ID") or "").strip()
        race          = str(char_data.get("Race")          or "Unknown").strip()
        sex           = str(char_data.get("Sex")           or "Unknown").strip()
        faction       = str(char_data.get("Faction")       or "Unknown").strip()
        origin_fac    = str(char_data.get("OriginFaction") or faction).strip()
        job           = str(char_data.get("Job")           or "None").strip()
        personality   = str(char_data.get("Personality")  or "").strip()
        backstory     = str(char_data.get("Backstory")     or "").strip()
        quirks        = str(char_data.get("SpeechQuirks")  or "").strip()
        relation      = char_data.get("Relation", 0)

        # Traits dict from personality_rules.generate_npc_traits()
        # Short descriptors — NOT prose, so no $ prefix.
        # These become normal relational fields that help retrieval.
        traits = char_data.get("Traits") or {}
        loyalty    = str(traits.get("Loyalty")    or "").strip()
        religion   = str(traits.get("Religion")   or "").strip()
        outlook    = str(traits.get("Outlook")    or "").strip()
        motivation = str(traits.get("Motivation") or "").strip()

        # Weight by relation (affects retrieval priority in Kayak)
        try:
            weight = 5 + max(-3, min(3, int(relation) // 20))
        except (ValueError, TypeError):
            weight = 5

        # Seed knowledge: preserve existing $knows_about if this NPC already has a
        # Kayak entity (they've been in conversations and may have grown their knowledge).
        # Only fall back to faction seed on first write (when no entity exists yet).
        _existing_fields = self.get_npc_fields(folder_name, persistent_id or None,
                                               campaign or self.campaign)
        _existing_knows  = _existing_fields.get("knows_about", "").strip()
        if _existing_knows:
            # Preserve grown knowledge — merge with seed so faction basics are never lost
            _seed_knowledge  = _build_initial_knowledge(faction, origin_fac)
            _existing_set    = {x.strip() for x in _existing_knows.split(",") if x.strip()}
            _merged          = _existing_set | _seed_knowledge
            knows_about_str  = ", ".join(sorted(_merged))
        else:
            # First write — seed from faction knowledge table
            _seed_knowledge = _build_initial_knowledge(faction, origin_fac)
            knows_about_str = ", ".join(sorted(_seed_knowledge)) if _seed_knowledge else ""

        lines = [
            f"Category = campaign_npcs",
            f"Name = {folder_name}",
            f"Id = {persistent_id}",
            "",
            f"persistent_id = {persistent_id}",
            f"display_name = {name}",
            f"race = {race}",
            f"sex = {sex}",
            f"faction = {faction}",
            f"origin_faction = {origin_fac}",
            f"role = {job}",
            f"weight = {weight}",
        ]
        if knows_about_str:
            lines.append(f"$knows_about = {knows_about_str}")

        # Traits as plain fields — short labels, no $ prefix, eligible for expansion
        if loyalty:
            lines.append(f"loyalty = {loyalty}")
        if religion:
            lines.append(f"religion = {religion}")
        if outlook:
            lines.append(f"outlook = {outlook}")
        if motivation:
            lines.append(f"motivation = {motivation}")

        # Prose fields — $ prefix = indexed for search but never used for layer expansion
        if personality:
            lines.append(f"$personality = {personality}")
        if backstory:
            lines.append(f"$backstory = {backstory}")
        if quirks:
            lines.append(f"$speech_quirks = {quirks}")

        content = "\n".join(lines)

        payload: Dict[str, Any] = {
            "category":       "campaign_npcs",
            "name":           folder_name,
            "entity_content": content,
        }
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign

        result = self._post("/write/npc", payload)
        if "error" in result:
            log.warning(f"[Kayak] write_npc_profile failed for {name}: {result['error']}")

    # ─── WRITE: STATS ────────────────────────────────────────────────────

    # ── Pricing helpers ─────────────────────────────────────────────────

    def _get_global_price_modifier(self) -> float:
        """
        Read the global price_modifier from Kayak config.
        Returns 1.0 on any error (no modification = safe default).
        """
        try:
            result = self._post("/config/get", {"key": "price_modifier"})
            return float(result.get("value", 1.0))
        except Exception:
            return 1.0

    def _get_city_price_modifier(
        self,
        town_name: str,
        campaign:  Optional[str] = None,
    ) -> float:
        """
        Read the price_modifier field from a city location entity.
        Returns 1.0 if absent (no city override).
        """
        if not town_name:
            return 1.0
        try:
            payload: Dict[str, Any] = {"target_npc": _to_folder_name(town_name)}
            if campaign or self.campaign:
                payload["campaign"] = campaign or self.campaign
            result = self._post("/entity/fields", payload)
            raw = result.get("fields", {}).get("price_modifier", "")
            return float(raw) if raw else 1.0
        except Exception:
            return 1.0

    def set_global_price_modifier(self, multiplier: float) -> bool:
        """
        Set the global price modifier and persist it to core_config.txt.
        This is the world baseline — city modifiers stack on top.
          effective = base_price_cats × global_modifier × city_modifier
        Examples: 1.2 = 20% world inflation.  0.8 = 20% world discount.
        """
        result = self._post("/config/set", {
            "key":   "price_modifier",
            "value": round(float(multiplier), 4),
        })
        ok = result.get("status") == "ok"
        if ok:
            log.info(f"[Kayak] Global price_modifier → {multiplier}")
        return ok

    def set_city_price_modifier(
        self,
        town_name:  str,
        multiplier: float,
        campaign:   Optional[str] = None,
    ) -> bool:
        """
        Set the price_modifier field on a city's location entity.
        Stacks on top of the global modifier.
          effective = base_price_cats × global_modifier × city_modifier
        Examples: 1.4 = city is 40% above global.  0.9 = 10% below global.
        """
        folder = _to_folder_name(town_name)
        if not folder:
            return False
        # Verify the city exists in the index first
        chk: Dict[str, Any] = {"target_npc": folder}
        if campaign or self.campaign:
            chk["campaign"] = campaign or self.campaign
        if not self._post("/entity/fields", chk).get("found"):
            log.warning(f"[Kayak] set_city_price_modifier: '{town_name}' not in index")
            return False
        result = self._post("/write/entity_field", {
            "name":     folder,
            "field":    "price_modifier",
            "value":    str(round(float(multiplier), 4)),
            **(({"campaign": campaign or self.campaign})
               if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        if ok:
            log.info(f"[Kayak] City price_modifier '{town_name}' → {multiplier}")
        return ok

    def write_stats_from_context(
        self,
        npc_name:   str,
        live_ctx:   Dict[str, Any],
        campaign:   Optional[str]       = None,
        shop_stock: Optional[List[str]] = None,
    ):
        """
        Write live stats to stats.txt from a SentientSands live context dict.
        No reindex needed — stats.txt is read fresh at prompt-time.

        shop_stock: item name strings the shopkeeper actually carries
        (from SS SHOP_STOCK[npc_name]).  When provided, injects a
        [SHOP INVENTORY] block with a strict sell-only-what-you-have rule.
        This prevents the LLM from offering items that appear in WORLD_CONTEXT
        but are not in the shopkeeper's actual stock.

        Hook location: inside /chat route, before calling build_chat_prompt(),
        using the result of resolve_live_context(name=primary_npc, ...).
        """
        if not live_ctx:
            return

        lines = [f"NPC: {npc_name}"]

        state = live_ctx.get("character_state", "normal")
        if state != "normal":
            lines.append(f"state: {state}")

        for key in ("race", "faction", "job", "money"):
            val = live_ctx.get(key)
            if val is not None:
                lines.append(f"{key}: {val}")

        med   = live_ctx.get("medical", {})
        if med:
            blood  = med.get("blood",      100)
            max_b  = med.get("max_blood",  100)
            hunger = med.get("hunger",     300)
            bpct   = int(blood / max_b * 100) if max_b > 0 else 100
            lines.append(f"blood: {bpct}%")
            if hunger < 100:
                lines.append("hunger: starving")
            elif hunger < 250:
                lines.append("hunger: hungry")

        env  = live_ctx.get("environment", {})
        town = ""
        if isinstance(env, dict):
            town = env.get("town_name", "")
            if town:
                lines.append(f"location: {town}")

        relation = live_ctx.get("relation")
        if relation is not None:
            lines.append(f"relation_to_player: {relation}")

        # ── PRICING block — shopkeepers and traders only ─────────────────────
        # effective_price = base_price_cats × global_modifier × city_modifier
        # Base prices come from item entity blocks in WORLD_CONTEXT.
        _is_trader  = live_ctx.get("is_trader", False)
        _in_shop    = live_ctx.get("in_shop", False)
        _job_lower  = str(live_ctx.get("job") or "").lower()
        if _is_trader or _in_shop or "shopkeeper" in _job_lower or "trader" in _job_lower:
            g_mod   = self._get_global_price_modifier()
            c_mod   = self._get_city_price_modifier(town, campaign)
            # Also read NPC-specific price_modifier (set via /k_npc_prices)
            _npc_fields = self.get_npc_fields(npc_name, None, campaign)
            _npc_pm_raw = _npc_fields.get("price_modifier", "")
            try:
                n_mod = float(_npc_pm_raw) if _npc_pm_raw else 1.0
            except (ValueError, TypeError):
                n_mod = 1.0
            eff     = round(g_mod * c_mod * n_mod, 4)
            if eff == 1.0:
                _price_note = "Prices are at standard base value."
            elif eff > 1.0:
                _pct = round((eff - 1.0) * 100)
                _price_note = (
                    f"Prices are {_pct}% above base "
                    f"(global \u00d7{g_mod}, city \u00d7{c_mod}, npc \u00d7{n_mod})."
                )
            else:
                _pct = round((1.0 - eff) * 100)
                _price_note = (
                    f"Prices are {_pct}% below base "
                    f"(global \u00d7{g_mod}, city \u00d7{c_mod}, npc \u00d7{n_mod})."
                )
            lines.append(
                f"[PRICING] multiplier={eff} | {_price_note} | "
                f"Multiply base_price_cats from WORLD_CONTEXT item blocks by {eff} "
                f"for the current asking price. Adjust \u00b110-20% further by personality."
            )

            # SHOP INVENTORY — authoritative sell list
            # shop_stock = SS SHOP_STOCK[npc_name] (shop container items).
            # Falls back to held inventory for non-shop traders.
            _held_inv = [
                i.get("name", "") for i in live_ctx.get("inventory", [])
                if not i.get("equipped") and i.get("name")
            ]
            _sell_list = shop_stock if shop_stock is not None else _held_inv
            if _sell_list:
                lines.append("[SHOP INVENTORY] Items available for purchase:")
                for _item_name in _sell_list:
                    lines.append(f"  - {_item_name}")
                lines.append(
                    "SELL RULE: ONLY sell items in SHOP INVENTORY above. "
                    "If asked for something not listed, say you don't carry it. "
                    "You may still quote the market value of items you lack "
                    "as general knowledge — e.g. 'I don't stock those, "
                    "but a decent one goes for about X cats elsewhere.'"
                )
            else:
                lines.append(
                    "[SHOP INVENTORY] Stock data unavailable — use your best "
                    "judgment about what a shopkeeper of your trade would carry."
                )

        payload: Dict[str, Any] = {
            "target_npc":    _to_folder_name(npc_name),
            "stats_content": "\n".join(lines),
        }
        pid = str(live_ctx.get("persistent_id") or "").strip()
        rid = str(live_ctx.get("runtime_id") or live_ctx.get("id") or "").strip()
        if pid:
            payload["persistent_id"] = pid
        elif rid:
            payload["runtime_id"] = rid

        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign

        self._post("/write/stats", payload)

    # ─── WRITE: WORLD EVENT ──────────────────────────────────────────────

    def write_world_event(
        self,
        name:     str,
        summary:  str,
        factions: Optional[List[str]] = None,
        location: str = "",
        radius:   str = "global",
        campaign: Optional[str] = None,
    ):
        """
        Write a world event (rumor, major event) as a Kayak entity.
        Enables contextual retrieval so NPCs near relevant factions receive
        this event naturally in their prompt context.

        Optional hook location: in generate_global_narrative_thread(), after
        generating a rumor.
        """
        folder_name = _to_folder_name(name)
        fac_str     = ", ".join(factions) if factions else ""

        lines = [
            f"Category = world_events",
            f"Name = {folder_name}",
            f"Id =",
            "",
            f"radius = {radius}",
        ]
        if location:
            lines.append(f"location = {location}")
        if fac_str:
            lines.append(f"factions_involved = {fac_str}")
        lines.append(f"$summary = {summary}")

        payload: Dict[str, Any] = {
            "name":           folder_name,
            "entity_content": "\n".join(lines),
        }
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign

        self._post("/write/world_event", payload)

    # ─── PROMPT BUILDING ─────────────────────────────────────────────────

    # ─── KNOWLEDGE FILTER (SS-specific logic — kept here, not in Kayak core) ──

    def get_npc_fields(
        self,
        target_npc:    str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> dict:
        """
        Fetch an NPC's entity fields from Kayak (e.g. $knows_about).
        Returns {} if not found or on any error.
        """
        payload: Dict[str, Any] = {"target_npc": _to_folder_name(target_npc)}
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        result = self._post("/entity/fields", payload)
        return result.get("fields", {})

    def _build_knowledge_filter(
        self,
        target_npc:    str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> Optional[List[str]]:
        """
        Build the knowledge_filter list to pass to /prompt/chat.

        Reads the NPC's $knows_about field from their entity. Returns None
        if the NPC has no filter (no profile yet → show everything, safe default).

        This is SentientSands-specific logic: the decision to filter world context
        by NPC knowledge lives here, not in Kayak core.
        """
        fields = self.get_npc_fields(target_npc, target_npc_id, campaign)
        raw = fields.get("knows_about", "").strip()  # $ stripped by /entity/fields
        if not raw:
            return None  # No filter — world context unrestricted
        items = [x.strip() for x in raw.split(",") if x.strip()]
        return items if items else None

    # ─── PROMPT BUILDING ─────────────────────────────────────────────────────

    # ─── ACTION HINT SYSTEM ──────────────────────────────────────────────────
    #
    # Scans the player message for keywords and injects a contextual [ACTION HINT]
    # block into extra_context before the prompt is assembled.
    #
    # Design rules:
    #   - Full action tag definitions stay in 3_action_tags.txt (always present)
    #   - Hints are ADDITIVE — they focus attention, never remove options
    #   - ATTACK is the most dangerous action (makes the NPC attack the player,
    #     causes them to leave the squad). Two separate keyword buckets:
    #       BATTLE_CRY  → suppress: "don't use ATTACK, this is a rally call"
    #       PERSONAL    → permit:   "ATTACK is valid — personal fight/training"
    #   - All other action hints are simple nudges toward the right tag
    #   - No keyword match = no hint = no extra tokens

    # Battle cry words — player rallying troops, NOT asking for personal combat
    _ATTACK_SUPPRESS = frozenset({
        "charge", "attack", "chaaarge", "ataack", "ataaack", "ataaaaack",
        "on me", "on my mark", "to arms", "forward", "advance",
        "get them", "get him", "get her", "get it",
        "fight them", "fight him", "fight her",
        "kill them", "kill him", "kill her",
        "take them down", "take him down", "take her down",
        "engage", "engage them", "engage the enemy",
        "move out", "move in", "hit them", "hit him", "hit her",
        "rush", "rush them", "destroy them", "destroy him",
        "wipe them out", "finish them",
    })

    # Personal combat words — player inviting THIS NPC to fight the player
    _ATTACK_PERMIT = frozenset({
        "attack me", "fight me", "hit me", "strike me", "come at me",
        "train me", "training", "let's train", "lets train",
        "train together", "spar", "sparring", "sparring match",
        "practice fight", "practice on me", "duel me", "duel",
        "show me what you got", "show me what you have got",
        "teach me to fight", "teach me combat", "beat me up",
    })

    # Other action hints: (trigger_keywords, hint_text)
    _ACTION_HINTS: list = [
        (
            frozenset({
                "join us", "join my squad", "join me", "join our group",
                "come with me", "come with us", "travel with us", "travel with me",
                "come along", "tag along", "recruit you", "i want to recruit",
                "would you join", "will you join",
                "be part of", "roll with us", "squad up", "team up",
            }),
            "[ACTION HINT] Recruitment: if you agree to join the player, you MUST "
            "use [ACTION: JOIN_PARTY] — agreeing in words alone has zero game effect.",
        ),
        (
            frozenset({
                "follow me", "follow us", "come here", "stay with me",
                "stick with me", "stay close", "walk with me", "keep up",
            }),
            "[ACTION HINT] Follow: if agreeing to follow the player informally "
            "(without joining squad), use [ACTION: FOLLOW_PLAYER].",
        ),
        (
            frozenset({
                "stay here", "wait here", "wait for me", "hold position",
                "stand guard", "stop following", "go back", "at ease",
                "dismissed", "you're dismissed", "leave me",
                "free to go", "go about your business",
            }),
            "[ACTION HINT] Dismiss/idle: use [ACTION: IDLE] to stop following "
            "or [ACTION: LEAVE] to formally leave the squad.",
        ),
        (
            frozenset({
                "heal", "heal them", "patch up", "medic", "need a medic",
                "they're hurt", "they're wounded", "fix them", "treat the wounds",
                "injured", "bleeding out",
            }),
            "[ACTION HINT] Medical: if asked to heal allies and you have the skills, "
            "use [ACTION: JOB_MEDIC].",
        ),
        (
            frozenset({
                "rescue", "save them", "they're down", "he's down", "she's down",
                "get them out", "carry them", "find them", "unconscious", "knocked out",
            }),
            "[ACTION HINT] Rescue: use [ACTION: FIND_AND_RESCUE] to retrieve "
            "and carry downed allies to safety.",
        ),
        (
            frozenset({
                "patrol", "keep watch", "guard the area", "guard this place",
                "walk the perimeter", "make rounds",
            }),
            "[ACTION HINT] Patrol: use [ACTION: PATROL_TOWN] if asked to guard "
            "or patrol the area.",
        ),
        (
            frozenset({
                "go home", "head home", "return home", "back to base",
                "return to base", "head back", "go back to base",
            }),
            "[ACTION HINT] Return home: use [ACTION: GO_HOMEBUILDING] to return "
            "to your assigned building.",
        ),
        (
            frozenset({
                "travel to", "go to", "head to", "make for", "set off for",
                "march to", "move to", "journey to",
            }),
            "[ACTION HINT] Travel: if agreeing to travel somewhere, use "
            "[ACTION: TRAVEL_TO_TARGET_TOWN: Town Name].",
        ),
        (
            frozenset({
                "fix yourself", "repair yourself", "repair them",
                "fix the skeleton", "maintenance", "patch yourself up",
            }),
            "[ACTION HINT] Repair: use [ACTION: JOB_REPAIR_ROBOT] to repair "
            "skeleton or robotic limbs.",
        ),
        (
            frozenset({
                "you're free", "you are free", "release them", "let them go",
                "unlock", "free them", "break them out", "let them out",
                "open the cage", "open the cell",
            }),
            "[ACTION HINT] Release: use [ACTION: FREE_PLAYER] (legal) or "
            "[ACTION: BREAKOUT_PLAYER] (illegal) to free a captive.",
        ),
        (
            frozenset({
                "back to your post", "man the counter", "get back to work",
                "return to the shop", "back to the stall", "tend the shop",
            }),
            "[ACTION HINT] Shopkeeper post: use [ACTION: STAND_AT_SHOPKEEPER_NODE] "
            "to return to your position behind the counter.",
        ),
    ]

    def _build_action_hint(self, player_message: str) -> Optional[str]:
        """
        Return a focused [ACTION HINT] string based on keywords in the player
        message, or None if nothing matches (zero extra tokens in that case).

        ATTACK is handled with two separate buckets:
          - Battle cry   -> suppression (do NOT use ATTACK on a rally call)
          - Personal     -> permission  (ATTACK is valid for training/duels)

        The returned string is appended to extra_context in build_chat_prompt.
        """
        msg = player_message.lower()
        hints: List[str] = []

        # Check personal combat first — overrides battle cry if both match
        _personal = any(kw in msg for kw in self._ATTACK_PERMIT)
        _cry      = any(kw in msg for kw in self._ATTACK_SUPPRESS)

        if _personal:
            hints.append(
                "[ACTION HINT] The player may be asking you to fight or train against them "
                "personally. [ACTION: ATTACK] is only appropriate if you have a genuine reason "
                "to engage THE PLAYER — a duel, a training session, or a real conflict between "
                "the two of you. Do not use it as a battle cry response. Remember: enemies already "
                "engage without commands — this action is exclusively for fighting the player."
            )
        elif _cry:
            hints.append(
                "[ACTION HINT] The player may be rallying their squad or giving a battle cry. "
                "Do NOT use [ACTION: ATTACK] unless the player makes it explicitly clear they "
                "want you to fight THEM personally. That action makes you leave the squad and "
                "attack the player — not the enemy. Enemies are hostile by default and engage "
                "without any command. If this is a call to arms, respond in character — readiness, "
                "agreement, battle energy — without emitting the ATTACK tag."
            )

        for trigger_set, hint_text in self._ACTION_HINTS:
            if any(kw in msg for kw in trigger_set):
                hints.append(hint_text)

        return "\n".join(hints) if hints else None

    def build_chat_prompt(
        self,
        player_message: str,
        target_npc:     Optional[str]       = None,
        target_npc_id:  Optional[str]       = None,
        mode:           str                 = "talk",
        extra_context:  Optional[str]       = None,
        keywords:       Optional[List[str]] = None,
        campaign:       Optional[str]       = None,
    ) -> str:
        """
        Build a chat prompt. Returns assembled prompt string, or "" on failure.

        extra_context: pass chronicle_str + events_str from SS here.
        They append after the player message so Kayak's mandatory rules
        and world context stay on top.

        The NPC's knowledge scope is computed here (SS-specific logic) and
        passed to Kayak as a generic knowledge_filter list. Kayak core
        applies it as a plain whitelist — no game-specific logic in the server.
        """
        payload: Dict[str, Any] = {
            "player_message": player_message,
            "mode":           mode.lower(),
        }
        if target_npc:
            payload["target_npc"] = _to_folder_name(target_npc)
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        # Action hint — appended to extra_context so it lands just before
        # the player message in the assembled prompt, focusing the LLM on
        # the relevant action tag(s) without removing any from the list.
        _action_hint = self._build_action_hint(player_message)
        if _action_hint:
            extra_context = ((extra_context + "\n\n") if extra_context else "") + _action_hint
            log.debug("[Kayak] action_hint injected (%d chars)", len(_action_hint))
        if extra_context:
            payload["extra_context"] = extra_context
        if keywords:
            payload["keywords"] = keywords
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign

        # Resolve knowledge filter — SS-specific, stays in bridge
        if target_npc:
            kf = self._build_knowledge_filter(target_npc, target_npc_id, campaign)
            if kf:
                payload["knowledge_filter"] = kf
                log.debug("[Kayak] knowledge_filter: %d entries for %s", len(kf), target_npc)

        result = self._post("/prompt/chat", payload)
        log.debug(
            "[Kayak] chat | target=%s world=%s kw=%s mode=%s",
            result.get("target"),
            result.get("world_context_count"),
            result.get("keywords_used"),
            mode,
        )
        return result.get("prompt", "")

    def build_loremaster_prompt(self, events: str, campaign: Optional[str] = None) -> str:
        payload: Dict[str, Any] = {"events": events}
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        return self._post("/prompt/loremaster", payload).get("prompt", "")

    def build_biography_prompt(self, npc_data: str, campaign: Optional[str] = None) -> str:
        payload: Dict[str, Any] = {"npc_data": npc_data}
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        return self._post("/prompt/biography", payload).get("prompt", "")

    # ─── DIALOGUE PERSISTENCE ────────────────────────────────────────────

    def save_dialogue(
        self,
        target_npc:    str,
        player_line:   str,
        npc_line:      str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
        location:      Optional[str] = None,
    ):
        """
        Persist a completed dialogue exchange for the PRIMARY NPC.
        Call AFTER the LLM has responded — never before.

        location: town_name from live context. When provided, the NPC's
        $knows_about field is grown to include this place — they've now
        been there and will be able to reference it in future conversations.
        """
        payload: Dict[str, Any] = {
            "target_npc":  _to_folder_name(target_npc),
            "player_line": player_line,
            "npc_line":    npc_line,
        }
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        self._post("/dialogue/save", payload)
        if location:
            self.grow_npc_knowledge(target_npc, location, target_npc_id, campaign)

    def grow_npc_knowledge(
        self,
        target_npc:    str,
        location:      str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ):
        """
        Add a location to an NPC's $knows_about field.
        The Kayak server validates the location against the index before writing,
        so this is safe to call with any string from the live context.
        """
        loc = _to_folder_name(location)
        if not loc:
            return
        payload: Dict[str, Any] = {
            "target_npc": _to_folder_name(target_npc),
            "location":   loc,
        }
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        self._post("/write/npc_knowledge", payload)

    def save_overheard_dialogue(
        self,
        target_npc:    str,
        player_line:   str,
        npc_line:      str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
        location:      Optional[str] = None,
    ):
        """
        Persist an overheard exchange for a bystander NPC.

        Called for each NPC in `listeners` who is NOT a direct participant.
        These NPCs were within earshot but didn't speak — SS marks their
        ConversationHistory with '(Overheard)'. Kayak mirrors this in
        dialogue.txt so the context is available in future conversations.

        Hook location: inside /chat route, in the listeners loop, for any NPC
        where is_overhearing=True, after save_character_data is called.
        """
        # Prefix both lines so the LLM knows this NPC only witnessed this
        payload: Dict[str, Any] = {
            "target_npc":  _to_folder_name(target_npc),
            "player_line": f"(Overheard) {player_line}" if player_line else "",
            "npc_line":    f"(Overheard) {npc_line}"    if npc_line    else "",
        }
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        self._post("/dialogue/save", payload)
        if location:
            self.grow_npc_knowledge(target_npc, location, target_npc_id, campaign)

    # ─── SPEAK PROMPT ─────────────────────────────────────────────────────

    def build_speak_prompt(
        self,
        line:       str,
        target_npc: Optional[str] = None,
        campaign:   Optional[str] = None,
    ) -> str:
        """
        Build a speak prompt — the LLM will repeat the line verbatim.
        Used by /k_speak: the response becomes a speech bubble with exactly
        the text the player commanded, without any normal chat scaffolding.
        """
        payload: Dict[str, Any] = {"line": line}
        if target_npc:
            payload["target_npc"] = _to_folder_name(target_npc)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        result = self._post("/prompt/speak", payload)
        return result.get("prompt", "")

    # ─── /k_ IN-GAME COMMANDS ─────────────────────────────────────────────
    # These are called from kenshi_llm_server.py when the player types a
    # /k_ command while talking to an NPC. All entity-edit commands return
    # a confirmation string. /k_speak is handled differently (see server hook).

    def k_visited(
        self,
        target_npc:    str,
        location:      str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """Add a city/location to the NPC's $knows_about field."""
        loc = _to_folder_name(location)
        if not loc:
            return f"[KAYAK] Invalid location name: '{location}'."
        payload: Dict[str, Any] = {
            "target_npc": _to_folder_name(target_npc),
            "location":   loc,
        }
        if target_npc_id:
            payload["target_npc_id"] = str(target_npc_id)
        if campaign or self.campaign:
            payload["campaign"] = campaign or self.campaign
        result = self._post("/write/npc_knowledge", payload)
        status = result.get("status")
        reason = result.get("reason", "")
        if status == "ok":
            return f"[KAYAK] {target_npc} now knows about {location}."
        elif status == "noop":
            if "already known" in reason:
                return f"[KAYAK] {target_npc} already knows about {location}."
            elif "not in index" in reason:
                return f"[KAYAK] '{location}' is not a known location in KayakDB."
            elif "not found" in reason:
                return f"[KAYAK] {target_npc} has no Kayak entity yet — talk to them first."
            return f"[KAYAK] Noop: {reason}"
        return f"[KAYAK] Failed to update {target_npc}'s knowledge: {result.get('error', 'unknown error')}"

    def k_job(
        self,
        target_npc:    str,
        job:           str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """Update the NPC's role field in their entity."""
        result = self._post("/write/entity_field", {
            "name":    _to_folder_name(target_npc),
            "field":   "role",
            "value":   job,
            **({"campaign": campaign or self.campaign} if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        return f"[KAYAK] {target_npc}'s job set to: {job}." if ok else f"[KAYAK] Failed to set job: {result.get('error', 'unknown error')}"

    def k_backstory(
        self,
        target_npc:    str,
        text:          str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """Append text to the NPC's $backstory field."""
        fields = self.get_npc_fields(target_npc, target_npc_id, campaign)
        existing = fields.get("backstory", "").strip()
        new_val  = (existing + " " + text).strip() if existing else text
        result = self._post("/write/entity_field", {
            "name":    _to_folder_name(target_npc),
            "field":   "$backstory",
            "value":   new_val,
            **({"campaign": campaign or self.campaign} if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        return f"[KAYAK] Backstory updated for {target_npc}." if ok else f"[KAYAK] Failed: {result.get('error', '?')}"

    def k_speech(
        self,
        target_npc:    str,
        text:          str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """Append text to the NPC's $speech_quirks field."""
        fields = self.get_npc_fields(target_npc, target_npc_id, campaign)
        existing = fields.get("speech_quirks", "").strip()
        new_val  = (existing + " " + text).strip() if existing else text
        result = self._post("/write/entity_field", {
            "name":    _to_folder_name(target_npc),
            "field":   "$speech_quirks",
            "value":   new_val,
            **({"campaign": campaign or self.campaign} if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        return f"[KAYAK] Speech quirks updated for {target_npc}." if ok else f"[KAYAK] Failed: {result.get('error', '?')}"

    def k_note(
        self,
        target_npc:    str,
        field:         str,
        value:         str,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """
        Set any field on the NPC entity directly.
        Prefix field with $ for prose (non-expandable), e.g. "$memory".
        No $ for relational fields, e.g. "loyalty".
        """
        result = self._post("/write/entity_field", {
            "name":    _to_folder_name(target_npc),
            "field":   field,
            "value":   value,
            **({"campaign": campaign or self.campaign} if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        return f"[KAYAK] {target_npc}: {field} = {value}" if ok else f"[KAYAK] Failed: {result.get('error', '?')}"

    def k_npc_prices(
        self,
        target_npc:    str,
        multiplier:    float,
        target_npc_id: Optional[str] = None,
        campaign:      Optional[str] = None,
    ) -> str:
        """
        Set a price_modifier on this specific NPC entity.
        Stacks on top of global AND city modifiers.
        effective = base × global × city × npc_modifier
        """
        result = self._post("/write/entity_field", {
            "name":    _to_folder_name(target_npc),
            "field":   "price_modifier",
            "value":   str(round(float(multiplier), 4)),
            **({"campaign": campaign or self.campaign} if (campaign or self.campaign) else {}),
        })
        ok = result.get("status") == "ok"
        pct = round((float(multiplier) - 1.0) * 100)
        direction = "above" if pct >= 0 else "below"
        return (
            f"[KAYAK] {target_npc} prices set to \u00d7{multiplier} ({abs(pct)}% {direction} city/global rate)."
            if ok else f"[KAYAK] Failed: {result.get('error', '?')}"
        )

    def k_help(self) -> str:
        """Return the /k_ command reference."""
        return (
            "[KAYAK] Available commands (target = NPC you are talking to):\n"
            "/k_visited <city>          Add a city to the NPC's known locations\n"
            "/k_job <role>              Change the NPC's role/job field\n"
            "/k_backstory <text>        Append to the NPC's backstory\n"
            "/k_speech <text>           Append to the NPC's speech quirks\n"
            "/k_note <field> <value>    Set any entity field (prefix with $ for prose)\n"
            "/k_npc_prices <mult>       Set this NPC's price modifier (e.g. 0.5, 1.5)\n"
            "/k_global_prices <mult>    Set the global price modifier\n"
            "/k_city_prices <city> <m>  Set a city's price modifier\n"
            "/k_speak <line>            Make the NPC say this line as a speech bubble\n"
            "/k_help                    Show this help"
        )

    # ─── STATUS / HOUSEKEEPING ───────────────────────────────────────────


    def is_alive(self) -> bool:
        try:
            r = requests.get(f"{self.kayak_url}/status", timeout=2.0)
            return r.status_code == 200
        except Exception:
            return False

    def status(self) -> dict:
        return self._get("/status")

    def reload_index(self) -> dict:
        return self._post("/campaign/reload_index", {})

    def reload_config(self) -> dict:
        return self._post("/config/reload", {})

    # ─── HTTP HELPERS ────────────────────────────────────────────────────

    def _get(self, path: str) -> dict:
        try:
            r = requests.get(f"{self.kayak_url}{path}", timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log.warning(f"[Kayak] GET {path} failed: {e}")
            return {}

    def _post(self, path: str, payload: dict) -> dict:
        try:
            r = requests.post(
                f"{self.kayak_url}{path}",
                json    = payload,
                timeout = self.timeout,
            )
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log.warning(f"[Kayak] POST {path} failed: {e}")
            return {}


# ─── UTILITIES ───────────────────────────────────────────────────────────────

def _clean_name(name: str) -> str:
    """Strip pipe-separated serial IDs (e.g. 'Tealc|12345' → 'Tealc')."""
    return str(name).split("|")[0].strip() if name else ""


def _to_folder_name(name: str) -> str:
    """Convert display name to a folder-safe identifier."""
    clean = _clean_name(name)
    return re.sub(r"[^\w\-]", "_", clean).strip("_")


def _read_text(path: str) -> str:
    """Read a text file safely, returning '' on any error."""
    try:
        if os.path.isfile(path):
            with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
                return fh.read()
    except Exception as e:
        log.debug(f"[Kayak] _read_text({path}): {e}")
    return ""
