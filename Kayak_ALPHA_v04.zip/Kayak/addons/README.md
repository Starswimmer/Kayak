# Kayak / addons

This directory is for third-party tools, mod content packages, and
any scripts that do not fit the Bridges model.

## What belongs here

- **Content packages**: A mod author can place a zip or rar file so that users can extract lore, NPC, faction or item files into the
  Template or into a named Campaign.

- **Maintenance tools**: Scripts that migrate old data, rename entities
  bulk-convert legacy formats, audit the KayakDB, or generate reports.

- **Server extensions**: If a mod wants to intercept or augment Kayak
  requests (e.g. a custom event watcher), it can run from here.

## What does NOT belong here

Bridges (input/output integration with a specific host mod) go in
`bridges/<mod_name>/`, not here.

## Running addon scripts

There is no automatic runner. You call addon scripts yourself, or
from your mod's setup logic. Example:

    python addons/UWE/install.py --campaign "MyRun"

## Responsibility

Addons have full filesystem access. If an addon modifies or deletes
campaign data, that is the addon's (and the user's) responsibility.
BACKUP YOUR CAMPAIGN FOLDER before extracting entity addons or running scripts.
