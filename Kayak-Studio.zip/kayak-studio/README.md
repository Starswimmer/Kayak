# Kayak Studio

Local authoring environment for Kayak / SentientSands content and AIDSL.  
Python backend + HTML frontend.

## Quick Start (Windows)

Double-click `start.bat`. It installs Flask, starts the server, and opens the browser.

## Manual Start

```bash
pip install flask
python server.py
```

Open `http://localhost:5000` and point it at your mod folder.

## Expected Mod Structure

```
ModRoot/
├── Kayak/KayakDB/
│   ├── Campaigns/{campaign}/
│   │   ├── categories/{category}/{entity}/entity.txt
│   │   └── mandatory/            (gameplay prompts)
│   └── Template/
│       ├── categories/
│       └── mandatory/
├── server/config/
│   ├── models.json
│   └── providers.json
├── config_master.txt             (INI, [SentientSands] section)
└── SentientSands_Config.ini      (legacy fallback)
```

The tool auto-resolves SentientSands subfolders (e.g. pointing at the Kenshi mods folder works).

## AI Drafting

Uses the mod's own `models.json` and `providers.json` — same provider/model setup as Kayak itself.
All providers use the OpenAI-compatible `/chat/completions` endpoint (same as the fan-made Prompt Explorer).
No separate API keys needed — it reads them from your existing config.

## Files

- `server.py` — Flask backend
- `parser.py` — Line-based AIDSL parser and document model
- `static/index.html` — Full editor UI
- `start.bat` — Windows launcher
