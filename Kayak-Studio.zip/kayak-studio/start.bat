@echo off
title Kayak Studio
echo.
echo  ╔══════════════════════════════════╗
echo  ║        KAYAK STUDIO              ║
echo  ╚══════════════════════════════════╝
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.10+ from python.org
    echo Make sure "Add Python to PATH" is checked during installation.
    pause
    exit /b 1
)

:: Install dependencies
echo Installing dependencies...
pip install flask --quiet --disable-pip-version-check >nul 2>&1
if errorlevel 1 (
    echo WARNING: pip install failed, trying with --user flag...
    pip install flask --quiet --user --disable-pip-version-check >nul 2>&1
)

echo Dependencies ready.
echo.
echo Starting Kayak Studio on http://localhost:5000
echo Press Ctrl+C to stop the server.
echo.

:: Open browser after a short delay
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:5000"

:: Start server
python server.py
