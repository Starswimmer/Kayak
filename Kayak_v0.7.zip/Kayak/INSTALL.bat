@echo off
title Kayak - Installation
echo =====================================
echo   Kayak v0.7 - Installing...
echo =====================================
echo.

pip install flask requests

echo.
if %errorlevel% == 0 (
    echo =====================================
    echo   Done! Kayak is ready.
    echo   You do NOT need to start it manually.
    echo   It starts automatically with SentientSands.
    echo =====================================
) else (
    echo =====================================
    echo   Something went wrong.
    echo   Make sure Python is installed and
    echo   added to PATH, then try again.
    echo =====================================
)

echo.
pause
